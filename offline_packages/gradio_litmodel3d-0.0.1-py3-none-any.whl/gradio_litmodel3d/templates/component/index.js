import { E as s, a as l, M as o, I as d } from "./Index-DFUH5UeF.js";
export {
  s as BaseExample,
  l as BaseModel3D,
  o as BaseModel3DUpload,
  d as default
};
